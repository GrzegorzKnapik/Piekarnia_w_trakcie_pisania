<?php
/* Smarty version 4.1.0, created on 2022-05-13 10:13:24
  from 'C:\Users\Sony_PC\Desktop\XAMP\htdocs\piekarnia\app\views\History_View_Db.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_627e132496c129_18226340',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4b943d747e541e64e87595179c9008fce00a4d1d' => 
    array (
      0 => 'C:\\Users\\Sony_PC\\Desktop\\XAMP\\htdocs\\piekarnia\\app\\views\\History_View_Db.tpl',
      1 => 1652428580,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:records_Db_View.tpl' => 1,
  ),
),false)) {
function content_627e132496c129_18226340 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1827259925627e1324961c89_78299811', 'content');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'content'} */
class Block_1827259925627e1324961c89_78299811 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_1827259925627e1324961c89_78299811',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>




<h1> Historia: </h1>
                <?php $_smarty_tpl->_subTemplateRender('file:records_Db_View.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
               
             
<?php
}
}
/* {/block 'content'} */
}
