<?php
/* Smarty version 4.1.0, created on 2022-05-15 18:42:37
  from 'C:\Users\Sony_PC\Desktop\XAMP\htdocs\piekarnia\app\views\LoginView.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_62812d7da3c046_34792531',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ed45d42924176ae5ef0fe86db9d4631cccb2da3c' => 
    array (
      0 => 'C:\\Users\\Sony_PC\\Desktop\\XAMP\\htdocs\\piekarnia\\app\\views\\LoginView.tpl',
      1 => 1652630745,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_62812d7da3c046_34792531 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>





<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_147122921962812d7da338a3_83234257', 'content');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'content'} */
class Block_147122921962812d7da338a3_83234257 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_147122921962812d7da338a3_83234257',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    

    
<form action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
login" method="post"  class="pure-form pure-form-aligned bottom-margin">
	<legend>Logowanie do systemu</legend>
	<fieldset>
        <div class="pure-control-group">
			<label for="id_login">login(numer telefonu): </label>
			<input id="id_login" type="text" name="login"/>
		</div>
        <div class="pure-control-group">
			<label for="id_pass">hasło: </label>
			<input id="id_pass" type="password" name="pass" /><br />
		</div>
		<div class="pure-controls">
			<input type="submit" value="zaloguj" class="pure-button pure-button-primary"/>
		</div>
	</fieldset>
</form>	

        <legend>Jesteś nowym klientem? Zarejestruj się</legend>
        
        
<div class="pure-menu pure-menu-horizontal bottom-margin">
	<a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
registration"  class="pure-menu-heading pure-menu-link">Rejestracja!</a>
</div>
        

<?php
}
}
/* {/block 'content'} */
}
