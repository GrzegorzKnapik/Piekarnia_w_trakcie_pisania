<?php

namespace app\controllers;

use core\App;
use core\Utils;
use core\RoleUtils;
use core\ParamUtils;
use app\forms\LoginForm;


class DbHistory
{
//zmienic na private te funkcje jedną!

   //public $data;
     public function action_showDbHistory()
    {
         
             Utils::addInfoMessage('Witam admina');
            $this->getFromDb();
           
        
    }
    
    
    
    /* unikalnosc loginu sprawdza i empty 
    $this->data = App::getDB()->select("registration", ["numer"],[
            "numer" => 728950772

      
        ]);
        
    */
    
    
    
    public function getFromDb()
    {
        # wywołanie obiektu Medoo
        
        //gut
        //$this->data = 0;
        $datat = App::getDB()->select("registration", ["haslo"],[
            "haslo[~]" => "%.jestem"

      
        ]);
        
        
         if(!empty($datat))
            {
                echo 'ijabfsabhuebhubauhbchusbhuabsuhbfcuv';
                Utils::addErrorMessage('Jesteś pracownikiem');
                
            }
        
            
            
         
       App::getSmarty()->assign('data', $this->data);
       
        
         $this->generateView();
        
    }

   

   
    public function generateView()
    {
       // getSmarty()->assign('user', unserialize($_SESSION['user']));
       
        
        App::getSmarty()->assign('page_title', 'Historia');
        App::getSmarty()->display('History_View_Db.tpl');
    }
}